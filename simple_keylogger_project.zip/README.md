# Simple Educational Keylogger

## ⚠ Ethical Notice
This project is **STRICTLY for educational purposes**.
Use it only on systems you **own** or where you have **explicit permission**.
Unauthorized use is illegal and unethical.

## Features
- Logs all key presses
- Saves logs to `keylog.txt`
- Stops safely when ESC is pressed
- No background hiding or persistence

## Installation
```bash
pip install -r requirements.txt
```

## Run
```bash
python main.py
```

## Stop
Press **ESC** to stop logging.
